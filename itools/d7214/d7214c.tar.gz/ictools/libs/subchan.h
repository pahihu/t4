/* @(#)subchan.h	1.1 3/25/91 */

/* subchan.h */
/* Copyright (C) Inmos Ltd. 1989 */

#ifndef _subchan_h
#define _subchan_h

#pragma IMS_on(channel_pointers)

typedef	void *_IMS_Channel;

#endif
