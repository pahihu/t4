For all PC's except a NEC PC:

BANSI.SYS is a replacement for ANSI.SYS in your CONFIG.SYS (see delivery
manual for further details).
