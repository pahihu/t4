#include <stdio.h>
#include <process.h>

void world(Process *p) 
  {
    p = p;
    printf("\nWorld\n");
  }

