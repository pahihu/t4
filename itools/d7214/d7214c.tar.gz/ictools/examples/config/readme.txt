(c) Copyright INMOS Ltd 1990. All Rights Reserved.

INMOS ANSI C Toolset ICCONF Examples
====================================

This directory contains the C configuration programs which are supplied
as part of the INMOS ANSI C Toolset to provide examples for the icconf
configuration tool. Also supplied are some configuration files that can
be used with the INMOS Module Motherboard Software to setup an IMS B008
transputer evaluation board for use with these example configurations.

(N.B. It is assumed in the C configuration programs that they are using
an IMS B008 or compatible with the TRAMS inserted into the slots of the
IMS B008 in increasing order. That is, making use of the hardwired pipe
line configuration of the IMS B008.)

The example C configuration programs are supplied with files that can
be used for building the programs. For all hosts there are make files
for each of the example programs that can be used with a UNIX style
make utility, if one is available for the host. If no make utility is
available as standard on the host then batch files are also supplied.

The make files that are supplied are constructed so that they can be
used on any host with a make file utility without modification. To use
the make files for each of the supported hosts it will be necessary to
specify on the command line of the make utility the switch character
used by the tools called from the make file for the host being used.

The following is a list of example command lines for calling the make
utility for each of the supported hosts:

    PC   : make S=/ -f <makefile>
    Sun3 : make S=- -f <makefile>
    Sun4 : make S=- -f <makefile>
    VAX  : make S=/ -f <makefile>

Note that the -f option is used to specify the name of the make file to
be used by the make utility and the S=<character> option specifies the
switch character (<character>) for the host.

The example programs that are supplied are listed as follows with a
brief description of their function and their hardware requirements.
Also listed will be the main configuration source file and its build
files for each of the supported hosts.

1) Hello world program

Hardware : 1 x T800

Source File : hello.cfs

Build Files : hello.mkf (PC, Sun3, Sun4, VAX)
              hello.bat (PC)
              hello.com (VAX)

2) Hello world program II

Hardware : 2 x T800

Source File : hello2.cfs

Build Files : hello2.mkf (PC, Sun3, Sun4, VAX)
              hello2.bat (PC)
              hello2.com (VAX)

3) Type passing program

Hardware : 1 x T800

Source File : types.cfs

Build Files : types.mkf (PC, Sun3, Sun4, VAX)
              types.bat (PC)
              types.com (VAX)

4) Pipe configuration program

Hardware : 5 x T800

Source File : pipe.cfs

Build Files : pipe.mkf (PC, Sun3, Sun4, VAX)
              pipe.bat (PC)
              pipe.com (VAX)

5) Ring configuration program

Hardware : 5 x T800

Source File : ring.cfs

Build Files : ring.mkf (PC, Sun3, Sun4, VAX)
              ring.bat (PC)
              ring.com (VAX)

6) Tree configuration program

Hardware : 5 x T800

Source File : tree.cfs

Build Files : tree.mkf (PC, Sun3, Sun4, VAX)
              tree.bat (PC)
              tree.com (VAX)

7) Square configuration program

Hardware : 5 x T800

Source File : square.cfs

Build Files : square.mkf (PC, Sun3, Sun4, VAX)
              square.bat (PC)
              square.com (VAX)

8) Square configuration program I

Hardware : 1 x T800

Source File : square1.cfs

Build Files : square1.mkf (PC, Sun3, Sun4, VAX)
              square1.bat (PC)
              square1.com (VAX)

9) Zigzag configuration program

Hardware : 5 x T800

Source File : zigzag.cfs

Build Files : zigzag.mkf (PC, Sun3, Sun4, VAX)
              zigzag.bat (PC)
              zigzag.com (VAX)


1 June 1990
