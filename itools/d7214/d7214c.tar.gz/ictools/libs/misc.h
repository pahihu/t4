/* @(#)misc.h	1.1 3/25/91 */

/* misc.h */
/* Copyright (C) Inmos Ltd. 1989 */

#ifndef __misc_h
#define __misc_h 1

#include <subsem.h>

#pragma IMS_translate(exit_repeat, "exit_repeat%c")
#pragma IMS_translate(exit_terminate, "exit_terminate%c")
#pragma IMS_translate(set_abort_action, "set_abort_action%c")
#pragma IMS_translate(debug_message, "debug_message%c")
#pragma IMS_translate(debug_assert, "debug_assert%c")
#pragma IMS_translate(debug_stop, "debug_stop%c")
#pragma IMS_translate(max_stack_usage, "max_stack_usage%c")
#pragma IMS_translate(get_param, "get_param%c")

extern void  exit_repeat(int /*n*/);
extern void  exit_terminate(int /*n*/);
extern int   set_abort_action(int /*n*/);
extern void  debug_message(const char * /*message*/);
extern void  debug_assert(const int /*expression*/);
extern void  debug_stop(void);
extern void *get_param(int /*n*/);
extern long  max_stack_usage(void);


#define ABORT_EXIT  0
#define ABORT_HALT  1
#define ABORT_QUERY 2

#endif
