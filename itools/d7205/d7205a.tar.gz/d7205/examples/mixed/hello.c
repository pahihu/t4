#include <stdio.h>
#include <misc.h>

int main()
{
  printf("\nC: Testing testing one two three ...\n");
  printf("\nC: Now I'm alive I think I will just ... hey, whats going on!\n");
  exit_terminate (0);
}
