/***************************************
*
*  Debugger example:  free.c
*
*  Cause a run time error by freeing an invalid pointer.
*  Debugger will locate to free () function call.
*
***************************************/


#include <stdlib.h>


int
main (void)

{
	
	/*  a random value other than NULL  */
	void*	ptr = (void *) 42;

	free (ptr);
}
