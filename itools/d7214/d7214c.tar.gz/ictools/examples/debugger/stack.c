/***************************************
*
*  Debugger example:  stack.c
*
*  An example of overflowing the stack and
*  using the debugger to locate.
*
*  Must be compiled with stack checking enabled.
*
***************************************/



void
foo (int a)

{
	foo (a);
}


int
main (void)

{
	foo (42);
}
