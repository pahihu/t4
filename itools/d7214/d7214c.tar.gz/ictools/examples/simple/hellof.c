#include <stdio.h>
#include <process.h>

void hello(Process *p) 
  {
    p = p;
    printf("\nHello,\n");
  }

