/* @(#)semaphor.h	1.2 4/2/91 */

/* semaphor.h */
/* Copyright (C) Inmos Ltd. 1989, 1990, 1991 */

#ifndef _semaphore_h
#define _semaphore_h

#include <subsem.h>
#include <channel.h>

typedef _IMS_Semaphore Semaphore;

#define	SEMAPHOREINIT(initvalue) \
                      {(initvalue),NULL,NULL,{1,NULL,NULL},{1,NULL,NULL}, \
                       0,(Channel)NotProcess_p}


#pragma IMS_translate(SemWait, "SemWait%c")
#pragma IMS_translate(SemSignal, "SemSignal%c")
#pragma IMS_translate(SemInit, "SemInit%c")
#pragma IMS_translate(SemAlloc, "SemAlloc%c")

extern void       SemWait(Semaphore * /*s*/);
extern void       SemSignal(Semaphore * /*s*/);
extern void       SemInit(Semaphore * /*s*/, int /*initvalue*/);
extern Semaphore *SemAlloc(int /*initvalue*/);

#endif
