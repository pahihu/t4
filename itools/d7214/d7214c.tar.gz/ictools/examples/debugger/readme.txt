PC has a make utility:
======================

Type:
	make all	-  to make all of the debugger examples
	make clean	-  to restore the examples to their original state





PC does not have a make utility:
================================

Type the name of the batch file for the example you wish to build.
